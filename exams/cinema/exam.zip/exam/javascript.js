/* note: two global variables created in cinema.js:
   var movies = [...]
   var schedule [...]
*/

/* your JS/jQuery code goes here */
