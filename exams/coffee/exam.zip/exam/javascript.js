/* Products array/objects given */

var products = [
    {
        image: "images/coffee.png",
        name: "Filter Coffee",
        price: 1.5,
        count: 0,
    },
    {
        image: "images/espresso.png",
        name: "Espresso",
        price: 1.0,
        count: 0,
    },
    {
        image: "images/cappuccino.png",
        name: "Cappuccino",
        price: 2.0,
        count: 0,
    },
    {
        image: "images/tea.png",
        name: "Tea",
        price: 1.0,
        count: 0,
    },
    {
        image: "images/chocolate.png",
        name: "Hot Chocolate",
        price: 1.5,
        count: 0,
    }
];

/* your JS code goes here */
